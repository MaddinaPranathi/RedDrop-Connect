import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { HeroLanding } from './components/hero-landing';
import { Dashboard } from './components/dashboard';
import { DonorRegistration } from './components/donor-registration';
import { BloodRequest } from './components/blood-request';
import { MapPage } from './components/map-page';
import { Profile } from './components/profile';
import { Alerts } from './components/alerts';
import { Camps } from './components/camps';

type Page = 
  | 'hero' 
  | 'dashboard' 
  | 'donor-registration' 
  | 'blood-request' 
  | 'map' 
  | 'profile' 
  | 'alerts' 
  | 'camps';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('hero');
  const [language, setLanguage] = useState<'en' | 'ta'>('en');

  // Smooth scroll to top on page change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentPage]);

  const handleNavigate = (page: string) => {
    setCurrentPage(page as Page);
  };

  const pageVariants = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -20 },
  };

  const pageTransition = {
    duration: 0.4,
    ease: 'easeInOut',
  };

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Language Toggle - Fixed Position */}
      <div className="fixed top-4 right-4 z-50">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setLanguage(language === 'en' ? 'ta' : 'en')}
          className="bg-white/20 backdrop-blur-md text-gray-900 px-4 py-2 rounded-full font-semibold shadow-lg border border-white/30"
          style={{
            backdropFilter: 'blur(12px)',
            WebkitBackdropFilter: 'blur(12px)',
          }}
        >
          {language === 'en' ? '🇮🇳 தமிழ்' : '🇬🇧 English'}
        </motion.button>
      </div>

      {/* Page Content with Animations */}
      <AnimatePresence mode="wait">
        {currentPage === 'hero' && (
          <motion.div
            key="hero"
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={pageTransition}
          >
            <HeroLanding onNavigate={handleNavigate} />
          </motion.div>
        )}

        {currentPage === 'dashboard' && (
          <motion.div
            key="dashboard"
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={pageTransition}
          >
            <Dashboard onNavigate={handleNavigate} />
          </motion.div>
        )}

        {currentPage === 'donor-registration' && (
          <motion.div
            key="donor-registration"
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={pageTransition}
          >
            <DonorRegistration onNavigate={handleNavigate} />
          </motion.div>
        )}

        {currentPage === 'blood-request' && (
          <motion.div
            key="blood-request"
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={pageTransition}
          >
            <BloodRequest onNavigate={handleNavigate} />
          </motion.div>
        )}

        {currentPage === 'map' && (
          <motion.div
            key="map"
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={pageTransition}
          >
            <MapPage onNavigate={handleNavigate} />
          </motion.div>
        )}

        {currentPage === 'profile' && (
          <motion.div
            key="profile"
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={pageTransition}
          >
            <Profile onNavigate={handleNavigate} />
          </motion.div>
        )}

        {currentPage === 'alerts' && (
          <motion.div
            key="alerts"
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={pageTransition}
          >
            <Alerts onNavigate={handleNavigate} />
          </motion.div>
        )}

        {currentPage === 'camps' && (
          <motion.div
            key="camps"
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={pageTransition}
          >
            <Camps onNavigate={handleNavigate} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer - Only show on non-hero pages */}
      {currentPage !== 'hero' && (
        <motion.footer
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="bg-gradient-to-r from-red-600 to-red-800 text-white py-8 px-6"
        >
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div>
                <h3 className="text-xl font-bold mb-4">BloodBridge</h3>
                <p className="text-white/80 text-sm">
                  Connecting lives through blood donation. Save lives, one drop at a time.
                </p>
              </div>
              <div>
                <h4 className="font-bold mb-4">Quick Links</h4>
                <ul className="space-y-2 text-sm text-white/80">
                  <li>
                    <button onClick={() => handleNavigate('dashboard')} className="hover:text-white">
                      Dashboard
                    </button>
                  </li>
                  <li>
                    <button onClick={() => handleNavigate('camps')} className="hover:text-white">
                      Blood Camps
                    </button>
                  </li>
                  <li>
                    <button onClick={() => handleNavigate('map')} className="hover:text-white">
                      Find Donors
                    </button>
                  </li>
                  <li>
                    <button onClick={() => handleNavigate('alerts')} className="hover:text-white">
                      Alerts
                    </button>
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold mb-4">Contact & Support</h4>
                <ul className="space-y-2 text-sm text-white/80">
                  <li>📞 +91 98765 43210</li>
                  <li>📧 support@bloodbridge.org</li>
                  <li>📍 Chennai, Tamil Nadu</li>
                  <li className="pt-2">
                    <a href="#" className="hover:text-white">FAQ</a> • <a href="#" className="hover:text-white">Privacy Policy</a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="border-t border-white/20 mt-8 pt-6 text-center text-sm text-white/60">
              <p>© 2026 BloodBridge. All rights reserved. Made with ❤️ for saving lives.</p>
            </div>
          </div>
        </motion.footer>
      )}
    </div>
  );
}

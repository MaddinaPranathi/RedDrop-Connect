import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Filter, User, Phone, Mail, Droplet, ChevronRight } from 'lucide-react';
import { GlassmorphicCard } from './glassmorphic-card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface MapPageProps {
  onNavigate: (page: string) => void;
}

const mockDonors = [
  { id: 1, name: 'Rajesh Kumar', bloodType: 'O+', distance: '1.2 km', availability: 'Available', location: { x: 35, y: 40 }, phone: '+91 98765 43210' },
  { id: 2, name: 'Priya Sharma', bloodType: 'A+', distance: '2.5 km', availability: 'Available', location: { x: 55, y: 30 }, phone: '+91 98765 43211' },
  { id: 3, name: 'Arun Menon', bloodType: 'B+', distance: '3.8 km', availability: 'Unavailable', location: { x: 45, y: 60 }, phone: '+91 98765 43212' },
  { id: 4, name: 'Lakshmi Iyer', bloodType: 'AB+', distance: '4.2 km', availability: 'Available', location: { x: 65, y: 45 }, phone: '+91 98765 43213' },
  { id: 5, name: 'Venkat Reddy', bloodType: 'O-', distance: '5.1 km', availability: 'Available', location: { x: 25, y: 55 }, phone: '+91 98765 43214' },
  { id: 6, name: 'Meera Nair', bloodType: 'A-', distance: '6.3 km', availability: 'Available', location: { x: 70, y: 25 }, phone: '+91 98765 43215' },
];

export function MapPage({ onNavigate }: MapPageProps) {
  const [selectedBloodGroup, setSelectedBloodGroup] = useState('');
  const [selectedAvailability, setSelectedAvailability] = useState('all');
  const [selectedDonor, setSelectedDonor] = useState<number | null>(null);

  const filteredDonors = mockDonors.filter(donor => {
    const bloodMatch = !selectedBloodGroup || donor.bloodType === selectedBloodGroup;
    const availabilityMatch = selectedAvailability === 'all' || 
      (selectedAvailability === 'available' && donor.availability === 'Available');
    return bloodMatch && availabilityMatch;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-red-50">
      <div className="flex flex-col lg:flex-row h-screen">
        {/* Map Section */}
        <div className="flex-1 relative">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="h-full bg-gradient-to-br from-blue-100 via-blue-50 to-green-50 relative"
          >
            {/* Filter Controls */}
            <div className="absolute top-4 left-4 right-4 z-10">
              <GlassmorphicCard>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-gray-700 text-sm mb-2 block font-semibold">
                      Blood Group
                    </label>
                    <Select value={selectedBloodGroup} onValueChange={setSelectedBloodGroup}>
                      <SelectTrigger className="bg-white/50">
                        <SelectValue placeholder="All types" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All Types</SelectItem>
                        <SelectItem value="A+">A+</SelectItem>
                        <SelectItem value="A-">A-</SelectItem>
                        <SelectItem value="B+">B+</SelectItem>
                        <SelectItem value="B-">B-</SelectItem>
                        <SelectItem value="O+">O+</SelectItem>
                        <SelectItem value="O-">O-</SelectItem>
                        <SelectItem value="AB+">AB+</SelectItem>
                        <SelectItem value="AB-">AB-</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-gray-700 text-sm mb-2 block font-semibold">
                      Availability
                    </label>
                    <Select value={selectedAvailability} onValueChange={setSelectedAvailability}>
                      <SelectTrigger className="bg-white/50">
                        <SelectValue placeholder="All donors" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Donors</SelectItem>
                        <SelectItem value="available">Available Only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-end">
                    <Button className="w-full bg-red-600 hover:bg-red-700 text-white">
                      <Filter className="mr-2" size={18} />
                      Apply Filters
                    </Button>
                  </div>
                </div>
              </GlassmorphicCard>
            </div>

            {/* Map with Donor Pins */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="relative w-full h-full">
                {/* Grid lines for map effect */}
                <div className="absolute inset-0 opacity-10">
                  {[...Array(10)].map((_, i) => (
                    <div key={`h-${i}`} className="absolute w-full h-px bg-gray-400" style={{ top: `${i * 10}%` }} />
                  ))}
                  {[...Array(10)].map((_, i) => (
                    <div key={`v-${i}`} className="absolute h-full w-px bg-gray-400" style={{ left: `${i * 10}%` }} />
                  ))}
                </div>

                {/* Heatmap Effect */}
                {filteredDonors.map((donor, i) => (
                  <motion.div
                    key={`heatmap-${donor.id}`}
                    className="absolute rounded-full bg-red-500/20"
                    style={{
                      left: `${donor.location.x}%`,
                      top: `${donor.location.y}%`,
                      width: '120px',
                      height: '120px',
                      transform: 'translate(-50%, -50%)',
                    }}
                    animate={{
                      scale: [1, 1.2, 1],
                      opacity: [0.2, 0.3, 0.2],
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      delay: i * 0.5,
                    }}
                  />
                ))}

                {/* Donor Pins */}
                {filteredDonors.map((donor) => (
                  <motion.div
                    key={donor.id}
                    className="absolute cursor-pointer"
                    style={{
                      left: `${donor.location.x}%`,
                      top: `${donor.location.y}%`,
                      transform: 'translate(-50%, -50%)',
                    }}
                    whileHover={{ scale: 1.2 }}
                    onClick={() => setSelectedDonor(donor.id)}
                    animate={{
                      y: [0, -10, 0],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                    }}
                  >
                    <div className={`relative ${donor.availability === 'Available' ? 'text-red-600' : 'text-gray-400'}`}>
                      <MapPin size={32} className="fill-current" />
                      <div className="absolute top-1 left-1/2 -translate-x-1/2 text-white text-xs font-bold">
                        {donor.bloodType}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Legend */}
            <div className="absolute bottom-4 left-4">
              <GlassmorphicCard hover={false} className="text-sm">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <MapPin size={20} className="text-red-600 fill-red-600" />
                    <span className="text-gray-700">Available Donor</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin size={20} className="text-gray-400 fill-gray-400" />
                    <span className="text-gray-700">Unavailable</span>
                  </div>
                </div>
              </GlassmorphicCard>
            </div>
          </motion.div>
        </div>

        {/* Donor List Sidebar */}
        <motion.div
          initial={{ x: 400 }}
          animate={{ x: 0 }}
          className="w-full lg:w-96 bg-white/30 backdrop-blur-md p-6 overflow-y-auto"
          style={{
            backdropFilter: 'blur(12px)',
            WebkitBackdropFilter: 'blur(12px)',
          }}
        >
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Nearby Donors ({filteredDonors.length})
          </h2>

          <div className="space-y-4">
            {filteredDonors.map((donor, index) => (
              <motion.div
                key={donor.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <GlassmorphicCard
                  className={`cursor-pointer ${
                    selectedDonor === donor.id ? 'ring-2 ring-red-600' : ''
                  }`}
                  onClick={() => setSelectedDonor(donor.id)}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-red-700 rounded-full flex items-center justify-center">
                        <User className="text-white" size={24} />
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-900">{donor.name}</h3>
                        <p className="text-sm text-gray-600">{donor.distance} away</p>
                      </div>
                    </div>
                    <div className="bg-red-600 text-white px-3 py-1 rounded-full text-sm font-bold">
                      {donor.bloodType}
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span
                      className={`text-sm font-semibold ${
                        donor.availability === 'Available' ? 'text-green-600' : 'text-gray-400'
                      }`}
                    >
                      {donor.availability}
                    </span>
                    <ChevronRight className="text-gray-400" size={20} />
                  </div>

                  <AnimatePresence>
                    {selectedDonor === donor.id && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="mt-4 pt-4 border-t border-gray-200"
                      >
                        <div className="space-y-2">
                          <div className="flex items-center gap-2 text-sm text-gray-700">
                            <Phone size={16} />
                            <span>{donor.phone}</span>
                          </div>
                          <Button className="w-full bg-red-600 hover:bg-red-700 text-white mt-2">
                            Contact Donor
                          </Button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </GlassmorphicCard>
              </motion.div>
            ))}
          </div>

          {filteredDonors.length === 0 && (
            <div className="text-center py-12">
              <Droplet size={48} className="text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600">No donors found with selected filters</p>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}

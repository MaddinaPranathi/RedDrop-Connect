import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { User, Droplet, CheckCircle, MapPin, ArrowRight, ArrowLeft } from 'lucide-react';
import { GlassmorphicCard } from './glassmorphic-card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { InputOTP, InputOTPGroup, InputOTPSlot } from './ui/input-otp';

interface DonorRegistrationProps {
  onNavigate: (page: string) => void;
}

export function DonorRegistration({ onNavigate }: DonorRegistrationProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    phone: '',
    email: '',
    bloodGroup: '',
    weight: '',
    lastDonation: '',
    medicalConditions: '',
    location: '',
    otp: '',
  });

  const totalSteps = 4;

  const handleNext = () => {
    if (step < totalSteps) setStep(step + 1);
  };

  const handlePrev = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleSubmit = () => {
    // Simulate registration
    setTimeout(() => {
      onNavigate('dashboard');
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-red-50 py-12 px-6">
      <div className="max-w-2xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Donor Registration</h1>
          <p className="text-gray-600">Join our life-saving community</p>
        </motion.div>

        {/* Progress Bar */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="mb-8"
        >
          <div className="flex justify-between items-center mb-2">
            {[1, 2, 3, 4].map((s) => (
              <div
                key={s}
                className={`flex-1 h-2 rounded-full mx-1 transition-all ${
                  s <= step ? 'bg-red-600' : 'bg-gray-200'
                }`}
              />
            ))}
          </div>
          <p className="text-center text-gray-600 text-sm">
            Step {step} of {totalSteps}
          </p>
        </motion.div>

        {/* Form Steps */}
        <GlassmorphicCard hover={false}>
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.3 }}
              >
                <div className="flex items-center gap-3 mb-6">
                  <User className="text-red-600" size={28} />
                  <h2 className="text-2xl font-bold text-gray-900">Personal Information</h2>
                </div>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Enter your full name"
                      className="bg-white/50"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="age">Age</Label>
                      <Input
                        id="age"
                        type="number"
                        value={formData.age}
                        onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                        placeholder="Age"
                        className="bg-white/50"
                      />
                    </div>
                    <div>
                      <Label htmlFor="weight">Weight (kg)</Label>
                      <Input
                        id="weight"
                        type="number"
                        value={formData.weight}
                        onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                        placeholder="Weight"
                        className="bg-white/50"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+91 XXXXX XXXXX"
                      className="bg-white/50"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="your.email@example.com"
                      className="bg-white/50"
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.3 }}
              >
                <div className="flex items-center gap-3 mb-6">
                  <Droplet className="text-red-600" size={28} />
                  <h2 className="text-2xl font-bold text-gray-900">Blood Group Selection</h2>
                </div>
                <div className="space-y-4">
                  <div>
                    <Label>Select Your Blood Group</Label>
                    <div className="grid grid-cols-4 gap-4 mt-2">
                      {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map((type) => (
                        <motion.button
                          key={type}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          onClick={() => setFormData({ ...formData, bloodGroup: type })}
                          className={`p-4 rounded-xl border-2 transition-all ${
                            formData.bloodGroup === type
                              ? 'bg-red-600 border-red-600 text-white'
                              : 'bg-white/50 border-gray-200 text-gray-900 hover:border-red-300'
                          }`}
                        >
                          <span className="text-2xl font-bold">{type}</span>
                        </motion.button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="lastDonation">Last Donation Date (Optional)</Label>
                    <Input
                      id="lastDonation"
                      type="date"
                      value={formData.lastDonation}
                      onChange={(e) => setFormData({ ...formData, lastDonation: e.target.value })}
                      className="bg-white/50"
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.3 }}
              >
                <div className="flex items-center gap-3 mb-6">
                  <CheckCircle className="text-red-600" size={28} />
                  <h2 className="text-2xl font-bold text-gray-900">Eligibility Quiz</h2>
                </div>
                <div className="space-y-6">
                  <div className="bg-white/50 p-4 rounded-xl">
                    <p className="font-semibold text-gray-900 mb-3">Are you currently:</p>
                    <div className="space-y-2">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" className="rounded text-red-600" />
                        <span className="text-gray-700">In good health</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" className="rounded text-red-600" />
                        <span className="text-gray-700">Not taking antibiotics</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" className="rounded text-red-600" />
                        <span className="text-gray-700">Not pregnant</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" className="rounded text-red-600" />
                        <span className="text-gray-700">No recent tattoos or piercings</span>
                      </label>
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="medical">Medical Conditions (Optional)</Label>
                    <Input
                      id="medical"
                      value={formData.medicalConditions}
                      onChange={(e) => setFormData({ ...formData, medicalConditions: e.target.value })}
                      placeholder="Any medical conditions we should know about"
                      className="bg-white/50"
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {step === 4 && (
              <motion.div
                key="step4"
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.3 }}
              >
                <div className="flex items-center gap-3 mb-6">
                  <MapPin className="text-red-600" size={28} />
                  <h2 className="text-2xl font-bold text-gray-900">Location & Verification</h2>
                </div>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="location">Location</Label>
                    <Select
                      value={formData.location}
                      onValueChange={(value) => setFormData({ ...formData, location: value })}
                    >
                      <SelectTrigger className="bg-white/50">
                        <SelectValue placeholder="Select your area" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="anna-nagar">Anna Nagar</SelectItem>
                        <SelectItem value="t-nagar">T. Nagar</SelectItem>
                        <SelectItem value="adyar">Adyar</SelectItem>
                        <SelectItem value="velachery">Velachery</SelectItem>
                        <SelectItem value="tambaram">Tambaram</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                    <p className="text-sm text-blue-900">
                      <strong>Location Consent:</strong> Your location will be used to connect you with nearby blood requests. We respect your privacy and will never share your exact address.
                    </p>
                  </div>
                  <div>
                    <Label>Enter OTP sent to {formData.phone}</Label>
                    <div className="flex justify-center mt-2">
                      <InputOTP
                        maxLength={6}
                        value={formData.otp}
                        onChange={(value) => setFormData({ ...formData, otp: value })}
                      >
                        <InputOTPGroup>
                          <InputOTPSlot index={0} />
                          <InputOTPSlot index={1} />
                          <InputOTPSlot index={2} />
                          <InputOTPSlot index={3} />
                          <InputOTPSlot index={4} />
                          <InputOTPSlot index={5} />
                        </InputOTPGroup>
                      </InputOTP>
                    </div>
                    <p className="text-center text-sm text-gray-600 mt-2">
                      Didn't receive? <span className="text-red-600 cursor-pointer">Resend OTP</span>
                    </p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8 pt-6 border-t border-gray-200">
            <Button
              onClick={handlePrev}
              variant="outline"
              disabled={step === 1}
              className={step === 1 ? 'invisible' : ''}
            >
              <ArrowLeft className="mr-2" size={18} />
              Previous
            </Button>
            {step < totalSteps ? (
              <Button onClick={handleNext} className="bg-red-600 hover:bg-red-700 text-white">
                Next
                <ArrowRight className="ml-2" size={18} />
              </Button>
            ) : (
              <Button onClick={handleSubmit} className="bg-red-600 hover:bg-red-700 text-white">
                <CheckCircle className="mr-2" size={18} />
                Complete Registration
              </Button>
            )}
          </div>
        </GlassmorphicCard>
      </div>
    </div>
  );
}

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Search, Droplet, UserPlus, Heart } from 'lucide-react';
import { GlassmorphicCard } from './glassmorphic-card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

const urgentRequests = [
  { id: 1, bloodType: 'O-', location: 'Apollo Hospital, Chennai', urgency: 'Critical', time: '2 hours ago' },
  { id: 2, bloodType: 'AB+', location: 'Fortis Malar, Chennai', urgency: 'Urgent', time: '4 hours ago' },
  { id: 3, bloodType: 'B+', location: 'MIOT Hospital, Chennai', urgency: 'Needed', time: '6 hours ago' },
];

interface HeroLandingProps {
  onNavigate: (page: string) => void;
}

export function HeroLanding({ onNavigate }: HeroLandingProps) {
  const [selectedBloodGroup, setSelectedBloodGroup] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [currentSlide, setCurrentSlide] = useState(0);

  React.useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % urgentRequests.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  const handleSearch = () => {
    if (selectedBloodGroup || selectedLocation) {
      onNavigate('map');
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Red Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-red-600 via-red-700 to-red-900" />
      
      {/* Animated Background Patterns */}
      <div className="absolute inset-0 opacity-10">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.3, 0.6, 0.3],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          >
            <Droplet size={20 + Math.random() * 40} className="text-white" />
          </motion.div>
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-6 py-12">
        {/* Logo */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex items-center justify-center mb-12 cursor-pointer"
          onClick={() => onNavigate('dashboard')}
        >
          <div className="relative">
            <Droplet size={48} className="text-white fill-white" />
            <Heart size={24} className="text-red-600 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
          </div>
          <span className="ml-4 text-3xl text-white font-bold">BloodBridge</span>
        </motion.div>

        {/* Hero Content */}
        <div className="max-w-4xl mx-auto text-center mb-16">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-6xl font-bold text-white mb-6"
          >
            Save Lives, One Drop at a Time
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="text-xl text-white/90 mb-12"
          >
            Connect blood donors with those in need across Chennai
          </motion.p>

          {/* Search Form */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <GlassmorphicCard className="max-w-3xl mx-auto">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                <div>
                  <label className="text-white text-sm mb-2 block">Blood Group</label>
                  <Select value={selectedBloodGroup} onValueChange={setSelectedBloodGroup}>
                    <SelectTrigger className="bg-white/30 border-white/50 text-white">
                      <SelectValue placeholder="Select blood type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="A+">A+</SelectItem>
                      <SelectItem value="A-">A-</SelectItem>
                      <SelectItem value="B+">B+</SelectItem>
                      <SelectItem value="B-">B-</SelectItem>
                      <SelectItem value="O+">O+</SelectItem>
                      <SelectItem value="O-">O-</SelectItem>
                      <SelectItem value="AB+">AB+</SelectItem>
                      <SelectItem value="AB-">AB-</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-white text-sm mb-2 block">Location</label>
                  <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                    <SelectTrigger className="bg-white/30 border-white/50 text-white">
                      <SelectValue placeholder="Select location" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="anna-nagar">Anna Nagar</SelectItem>
                      <SelectItem value="t-nagar">T. Nagar</SelectItem>
                      <SelectItem value="adyar">Adyar</SelectItem>
                      <SelectItem value="velachery">Velachery</SelectItem>
                      <SelectItem value="tambaram">Tambaram</SelectItem>
                      <SelectItem value="chromepet">Chromepet</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button
                  onClick={handleSearch}
                  className="bg-gradient-to-r from-red-500 to-red-700 hover:from-red-600 hover:to-red-800 text-white h-10"
                >
                  <Search className="mr-2" size={18} />
                  Search Donors
                </Button>
              </div>
            </GlassmorphicCard>
          </motion.div>
        </div>

        {/* Urgent Requests Carousel */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="max-w-2xl mx-auto mb-12"
        >
          <h2 className="text-2xl font-bold text-white mb-4 text-center">Urgent Requests</h2>
          <div className="relative h-32 overflow-hidden">
            {urgentRequests.map((request, index) => (
              <motion.div
                key={request.id}
                initial={{ opacity: 0, x: 100 }}
                animate={{
                  opacity: currentSlide === index ? 1 : 0,
                  x: currentSlide === index ? 0 : -100,
                  display: currentSlide === index ? 'block' : 'none',
                }}
                transition={{ duration: 0.5 }}
                className="absolute inset-0"
              >
                <GlassmorphicCard className="h-full">
                  <div className="flex items-center justify-between h-full">
                    <div className="flex items-center gap-4">
                      <div className="bg-red-600 rounded-full w-16 h-16 flex items-center justify-center">
                        <span className="text-white text-xl font-bold">{request.bloodType}</span>
                      </div>
                      <div>
                        <p className="text-white font-semibold">{request.location}</p>
                        <p className="text-white/70 text-sm">{request.time}</p>
                      </div>
                    </div>
                    <motion.div
                      animate={{ scale: [1, 1.1, 1] }}
                      transition={{ duration: 1, repeat: Infinity }}
                      className={`px-4 py-2 rounded-full ${
                        request.urgency === 'Critical'
                          ? 'bg-red-600'
                          : request.urgency === 'Urgent'
                          ? 'bg-orange-500'
                          : 'bg-yellow-500'
                      }`}
                    >
                      <span className="text-white font-semibold">{request.urgency}</span>
                    </motion.div>
                  </div>
                </GlassmorphicCard>
              </motion.div>
            ))}
          </div>
          <div className="flex justify-center gap-2 mt-4">
            {urgentRequests.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-2 h-2 rounded-full transition-all ${
                  currentSlide === index ? 'bg-white w-8' : 'bg-white/50'
                }`}
              />
            ))}
          </div>
        </motion.div>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1 }}
          className="flex flex-col md:flex-row gap-6 justify-center"
        >
          <Button
            onClick={() => onNavigate('donor-registration')}
            size="lg"
            className="bg-white text-red-600 hover:bg-white/90 text-lg px-8 py-6 rounded-2xl"
          >
            <UserPlus className="mr-2" size={24} />
            Register as Donor
          </Button>
          <Button
            onClick={() => onNavigate('blood-request')}
            size="lg"
            className="bg-gradient-to-r from-red-500 to-red-700 hover:from-red-600 hover:to-red-800 text-white text-lg px-8 py-6 rounded-2xl"
          >
            <Heart className="mr-2" size={24} />
            Request Blood
          </Button>
        </motion.div>
      </div>
    </div>
  );
}

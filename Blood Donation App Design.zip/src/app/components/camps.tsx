import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, MapPin, Users, Clock, Heart, ChevronLeft, ChevronRight, Building2 } from 'lucide-react';
import { GlassmorphicCard } from './glassmorphic-card';
import { Button } from './ui/button';

interface CampsProps {
  onNavigate: (page: string) => void;
}

const bloodCamps = [
  {
    id: 1,
    name: 'Chennai Blood Donation Camp',
    date: '2026-02-15',
    time: '9:00 AM - 5:00 PM',
    location: 'Anna Nagar Community Hall',
    address: 'Plot No. 123, 2nd Avenue, Anna Nagar, Chennai',
    organizer: 'Chennai Blood Bank',
    expectedDonors: 200,
    registered: 145,
  },
  {
    id: 2,
    name: 'Corporate Blood Drive',
    date: '2026-02-18',
    time: '10:00 AM - 4:00 PM',
    location: 'Tech Park, Taramani',
    address: 'IT Corridor, Taramani, Chennai',
    organizer: 'Tech Companies Alliance',
    expectedDonors: 150,
    registered: 87,
  },
  {
    id: 3,
    name: 'University Health Camp',
    date: '2026-02-22',
    time: '8:00 AM - 2:00 PM',
    location: 'Anna University Campus',
    address: 'Sardar Patel Road, Guindy, Chennai',
    organizer: 'Anna University Health Center',
    expectedDonors: 300,
    registered: 256,
  },
];

const successStories = [
  {
    id: 1,
    title: 'Emergency Surgery Saved',
    story: 'Thanks to quick responses from our donors, a critical accident victim received 4 units of O- blood within 2 hours, enabling life-saving surgery.',
    donor: 'Multiple Donors',
    date: 'January 2026',
    image: '🏥',
  },
  {
    id: 2,
    title: 'Cancer Patient Support',
    story: 'Regular donors helped a leukemia patient receive consistent blood transfusions throughout their treatment. They are now in remission!',
    donor: 'Regular Donors',
    date: 'December 2025',
    image: '💪',
  },
  {
    id: 3,
    title: 'Mother & Child Saved',
    story: 'Urgent blood donation during complicated delivery saved both mother and newborn. The family is forever grateful to our donor community.',
    donor: 'Emergency Donors',
    date: 'November 2025',
    image: '👶',
  },
];

const partnerHospitals = [
  { id: 1, name: 'Apollo Hospital', location: 'Greams Road', beds: 500 },
  { id: 2, name: 'Fortis Malar Hospital', location: 'Adyar', beds: 180 },
  { id: 3, name: 'MIOT International', location: 'Manapakkam', beds: 1000 },
  { id: 4, name: 'Gleneagles Global', location: 'Perumbakkam', beds: 350 },
  { id: 5, name: 'Kauvery Hospital', location: 'Alwarpet', beds: 200 },
  { id: 6, name: 'Sri Ramachandra Hospital', location: 'Porur', beds: 600 },
];

export function Camps({ onNavigate }: CampsProps) {
  const [currentStory, setCurrentStory] = useState(0);

  const nextStory = () => {
    setCurrentStory((prev) => (prev + 1) % successStories.length);
  };

  const prevStory = () => {
    setCurrentStory((prev) => (prev - 1 + successStories.length) % successStories.length);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-red-50 py-12 px-6">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Blood Camps & Stories</h1>
          <p className="text-gray-600">Join upcoming camps and read inspiring success stories</p>
        </motion.div>

        {/* Upcoming Blood Camps */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-12"
        >
          <div className="flex items-center gap-3 mb-6">
            <Calendar className="text-red-600" size={32} />
            <h2 className="text-3xl font-bold text-gray-900">Upcoming Blood Camps</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {bloodCamps.map((camp, index) => (
              <motion.div
                key={camp.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + index * 0.1 }}
              >
                <GlassmorphicCard className="h-full">
                  <div className="mb-4">
                    <div className="bg-gradient-to-r from-red-500 to-red-700 text-white px-4 py-2 rounded-xl inline-block mb-3">
                      <p className="font-bold">
                        {new Date(camp.date).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                        })}
                      </p>
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{camp.name}</h3>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-start gap-2 text-sm text-gray-700">
                      <Clock size={16} className="mt-0.5 flex-shrink-0" />
                      <span>{camp.time}</span>
                    </div>
                    <div className="flex items-start gap-2 text-sm text-gray-700">
                      <MapPin size={16} className="mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-semibold">{camp.location}</p>
                        <p className="text-gray-600">{camp.address}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-700">
                      <Building2 size={16} />
                      <span>{camp.organizer}</span>
                    </div>
                  </div>

                  <div className="bg-white/50 rounded-lg p-3 mb-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-gray-600">Registration Progress</span>
                      <span className="text-sm font-bold text-gray-900">
                        {camp.registered}/{camp.expectedDonors}
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${(camp.registered / camp.expectedDonors) * 100}%` }}
                        transition={{ duration: 1, delay: 0.2 + index * 0.1 }}
                        className="bg-gradient-to-r from-red-500 to-red-700 h-2 rounded-full"
                      />
                    </div>
                  </div>

                  <Button className="w-full bg-red-600 hover:bg-red-700 text-white">
                    <Heart className="mr-2" size={18} />
                    Register Now
                  </Button>
                </GlassmorphicCard>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Success Stories Slider */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-12"
        >
          <div className="flex items-center gap-3 mb-6">
            <Heart className="text-red-600" size={32} />
            <h2 className="text-3xl font-bold text-gray-900">Success Stories</h2>
          </div>
          <GlassmorphicCard hover={false}>
            <div className="relative">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentStory}
                  initial={{ opacity: 0, x: 100 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -100 }}
                  transition={{ duration: 0.3 }}
                  className="text-center py-8"
                >
                  <div className="text-6xl mb-4">{successStories[currentStory].image}</div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">
                    {successStories[currentStory].title}
                  </h3>
                  <p className="text-gray-700 mb-6 max-w-2xl mx-auto leading-relaxed">
                    {successStories[currentStory].story}
                  </p>
                  <div className="flex items-center justify-center gap-4 text-sm text-gray-600">
                    <div className="flex items-center gap-2">
                      <Users size={16} />
                      <span>{successStories[currentStory].donor}</span>
                    </div>
                    <span>•</span>
                    <span>{successStories[currentStory].date}</span>
                  </div>
                </motion.div>
              </AnimatePresence>

              {/* Navigation Arrows */}
              <div className="flex justify-between items-center mt-6">
                <Button
                  onClick={prevStory}
                  variant="outline"
                  className="rounded-full w-10 h-10 p-0"
                >
                  <ChevronLeft size={20} />
                </Button>
                <div className="flex gap-2">
                  {successStories.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentStory(index)}
                      className={`w-2 h-2 rounded-full transition-all ${
                        currentStory === index ? 'bg-red-600 w-8' : 'bg-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <Button
                  onClick={nextStory}
                  variant="outline"
                  className="rounded-full w-10 h-10 p-0"
                >
                  <ChevronRight size={20} />
                </Button>
              </div>
            </div>
          </GlassmorphicCard>
        </motion.div>

        {/* Partner Hospitals */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <div className="flex items-center gap-3 mb-6">
            <Building2 className="text-red-600" size={32} />
            <h2 className="text-3xl font-bold text-gray-900">Partner Hospitals</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {partnerHospitals.map((hospital, index) => (
              <motion.div
                key={hospital.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.6 + index * 0.05 }}
              >
                <GlassmorphicCard>
                  <div className="flex items-start gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-700 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Building2 className="text-white" size={24} />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900">{hospital.name}</h3>
                      <div className="flex items-center gap-2 text-sm text-gray-600 mt-1">
                        <MapPin size={14} />
                        <span>{hospital.location}</span>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">{hospital.beds} beds</p>
                    </div>
                  </div>
                </GlassmorphicCard>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
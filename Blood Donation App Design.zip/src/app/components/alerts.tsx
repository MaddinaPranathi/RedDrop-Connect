import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Bell, Clock, MapPin, Droplet, Check, X } from 'lucide-react';
import { GlassmorphicCard } from './glassmorphic-card';
import { Button } from './ui/button';

interface AlertsProps {
  onNavigate: (page: string) => void;
}

const urgentAlerts = [
  {
    id: 1,
    bloodType: 'O-',
    location: 'Apollo Hospital, Anna Nagar',
    urgency: 'Critical',
    timeLeft: 180, // minutes
    distance: '1.2 km',
    unitsNeeded: 2,
  },
  {
    id: 2,
    bloodType: 'AB+',
    location: 'Fortis Malar, Adyar',
    urgency: 'Urgent',
    timeLeft: 420,
    distance: '3.5 km',
    unitsNeeded: 1,
  },
  {
    id: 3,
    bloodType: 'B+',
    location: 'MIOT Hospital, Manapakkam',
    urgency: 'Needed',
    timeLeft: 1200,
    distance: '5.8 km',
    unitsNeeded: 3,
  },
];

function CountdownTimer({ minutes }: { minutes: number }) {
  const [timeLeft, setTimeLeft] = useState(minutes * 60);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const hours = Math.floor(timeLeft / 3600);
  const mins = Math.floor((timeLeft % 3600) / 60);
  const secs = timeLeft % 60;

  return (
    <div className="flex items-center gap-2">
      <Clock size={18} />
      <span className="font-mono font-bold">
        {hours.toString().padStart(2, '0')}:{mins.toString().padStart(2, '0')}:
        {secs.toString().padStart(2, '0')}
      </span>
    </div>
  );
}

export function Alerts({ onNavigate }: AlertsProps) {
  const [respondedAlerts, setRespondedAlerts] = useState<number[]>([]);
  const [dismissedAlerts, setDismissedAlerts] = useState<number[]>([]);

  const handleRespond = (id: number) => {
    setRespondedAlerts([...respondedAlerts, id]);
  };

  const handleDismiss = (id: number) => {
    setDismissedAlerts([...dismissedAlerts, id]);
  };

  const visibleAlerts = urgentAlerts.filter((alert) => !dismissedAlerts.includes(alert.id));

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-red-50 py-12 px-6">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <Bell size={40} className="text-red-600" />
            <h1 className="text-4xl font-bold text-gray-900">Urgent Alerts</h1>
          </div>
          <p className="text-gray-600">Lives need your help - respond to urgent blood requests</p>
        </motion.div>

        {/* Stats Banner */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <GlassmorphicCard hover={false}>
            <div className="grid grid-cols-3 gap-6 text-center">
              <div>
                <p className="text-3xl font-bold text-red-600">{visibleAlerts.length}</p>
                <p className="text-gray-600 text-sm">Active Alerts</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-green-600">{respondedAlerts.length}</p>
                <p className="text-gray-600 text-sm">Your Responses</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-blue-600">
                  {visibleAlerts.filter((a) => a.urgency === 'Critical').length}
                </p>
                <p className="text-gray-600 text-sm">Critical Cases</p>
              </div>
            </div>
          </GlassmorphicCard>
        </motion.div>

        {/* Alerts List */}
        <div className="space-y-6">
          {visibleAlerts.map((alert, index) => {
            const isResponded = respondedAlerts.includes(alert.id);
            const urgencyColors = {
              Critical: 'from-red-500 to-red-700',
              Urgent: 'from-orange-500 to-orange-700',
              Needed: 'from-yellow-500 to-yellow-700',
            };

            return (
              <motion.div
                key={alert.id}
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <GlassmorphicCard
                  hover={false}
                  className={isResponded ? 'ring-2 ring-green-500' : ''}
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex-1">
                      {/* Blood Type Badge */}
                      <div className="flex items-center gap-4 mb-3">
                        <div
                          className={`bg-gradient-to-br ${urgencyColors[alert.urgency as keyof typeof urgencyColors]} text-white px-4 py-2 rounded-xl`}
                        >
                          <span className="text-2xl font-bold">{alert.bloodType}</span>
                        </div>
                        <div>
                          <motion.div
                            animate={alert.urgency === 'Critical' ? { scale: [1, 1.05, 1] } : {}}
                            transition={{ duration: 1, repeat: Infinity }}
                            className={`px-3 py-1 rounded-full text-white text-sm font-bold ${
                              alert.urgency === 'Critical'
                                ? 'bg-red-600'
                                : alert.urgency === 'Urgent'
                                ? 'bg-orange-500'
                                : 'bg-yellow-500'
                            }`}
                          >
                            {alert.urgency}
                          </motion.div>
                          <p className="text-sm text-gray-600 mt-1">{alert.unitsNeeded} units needed</p>
                        </div>
                      </div>

                      {/* Location */}
                      <div className="flex items-start gap-2 mb-2">
                        <MapPin size={18} className="text-gray-600 mt-0.5" />
                        <div>
                          <p className="font-semibold text-gray-900">{alert.location}</p>
                          <p className="text-sm text-gray-600">{alert.distance} from you</p>
                        </div>
                      </div>

                      {/* Countdown */}
                      <div
                        className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg ${
                          alert.timeLeft < 240
                            ? 'bg-red-100 text-red-700'
                            : alert.timeLeft < 600
                            ? 'bg-orange-100 text-orange-700'
                            : 'bg-yellow-100 text-yellow-700'
                        }`}
                      >
                        <CountdownTimer minutes={alert.timeLeft / 60} />
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex md:flex-col gap-2">
                      {!isResponded ? (
                        <>
                          <Button
                            onClick={() => handleRespond(alert.id)}
                            className="flex-1 md:flex-none bg-green-600 hover:bg-green-700 text-white"
                          >
                            <Check className="mr-2" size={18} />
                            I'm Available
                          </Button>
                          <Button
                            onClick={() => handleDismiss(alert.id)}
                            variant="outline"
                            className="flex-1 md:flex-none"
                          >
                            <X className="mr-2" size={18} />
                            Dismiss
                          </Button>
                        </>
                      ) : (
                        <div className="bg-green-100 text-green-700 px-4 py-3 rounded-xl text-center">
                          <Check className="inline mr-2" size={18} />
                          <span className="font-semibold">Response Sent!</span>
                          <p className="text-xs mt-1">Hospital will contact you shortly</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {isResponded && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="mt-4 pt-4 border-t border-gray-200"
                    >
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <h4 className="font-semibold text-blue-900 mb-2">Next Steps:</h4>
                        <ul className="text-sm text-blue-800 space-y-1 list-disc list-inside">
                          <li>Hospital staff will verify your availability</li>
                          <li>You'll receive a confirmation call/SMS</li>
                          <li>Please ensure you're well-rested before donation</li>
                        </ul>
                      </div>
                    </motion.div>
                  )}
                </GlassmorphicCard>
              </motion.div>
            );
          })}
        </div>

        {visibleAlerts.length === 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-12"
          >
            <GlassmorphicCard hover={false}>
              <Droplet size={64} className="text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">No Active Alerts</h3>
              <p className="text-gray-600 mb-6">Great! There are no urgent requests at the moment.</p>
              <Button
                onClick={() => onNavigate('dashboard')}
                className="bg-red-600 hover:bg-red-700 text-white"
              >
                Back to Dashboard
              </Button>
            </GlassmorphicCard>
          </motion.div>
        )}

        {/* Info Card */}
        {visibleAlerts.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mt-8"
          >
            <GlassmorphicCard hover={false} className="bg-gradient-to-r from-blue-50 to-purple-50">
              <h3 className="font-bold text-gray-900 mb-2">💡 Quick Tip</h3>
              <p className="text-gray-700 text-sm">
                Responding to alerts helps save lives! Make sure you're eligible to donate before
                confirming. You can donate whole blood every 3 months.
              </p>
            </GlassmorphicCard>
          </motion.div>
        )}
      </div>
    </div>
  );
}

import React from 'react';
import { motion } from 'motion/react';
import { Home, User, FileText, MapPin, Bell, Droplet, Users, Calendar, TrendingUp, Menu, X } from 'lucide-react';
import { GlassmorphicCard } from './glassmorphic-card';
import { Button } from './ui/button';

interface DashboardProps {
  onNavigate: (page: string) => void;
}

const statsData = [
  { label: 'Your Blood Type', value: 'O+', icon: Droplet, color: 'bg-red-500' },
  { label: 'Nearby Donors', value: '247', icon: Users, color: 'bg-blue-500' },
  { label: 'Recent Camps', value: '12', icon: Calendar, color: 'bg-green-500' },
  { label: 'Lives Saved', value: '8', icon: TrendingUp, color: 'bg-purple-500' },
];

const quickActions = [
  { label: 'Request Blood', page: 'blood-request', icon: Droplet, color: 'bg-red-500' },
  { label: 'View Map', page: 'map', icon: MapPin, color: 'bg-blue-500' },
  { label: 'My Profile', page: 'profile', icon: User, color: 'bg-green-500' },
  { label: 'Blood Camps', page: 'camps', icon: Calendar, color: 'bg-purple-500' },
];

export function Dashboard({ onNavigate }: DashboardProps) {
  const [sidebarOpen, setSidebarOpen] = React.useState(false);

  const navItems = [
    { label: 'Home', icon: Home, page: 'dashboard' },
    { label: 'Profile', icon: User, page: 'profile' },
    { label: 'Requests', icon: FileText, page: 'blood-request' },
    { label: 'Map', icon: MapPin, page: 'map' },
    { label: 'Alerts', icon: Bell, page: 'alerts' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-red-50">
      {/* Mobile Menu Button */}
      <div className="md:hidden fixed top-4 left-4 z-50">
        <Button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="bg-red-600 hover:bg-red-700 text-white rounded-full p-3"
        >
          {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
        </Button>
      </div>

      {/* Sidebar */}
      <motion.aside
        initial={{ x: -300 }}
        animate={{ x: sidebarOpen ? 0 : -300 }}
        className="fixed left-0 top-0 h-full w-64 bg-gradient-to-b from-red-600 to-red-800 p-6 z-40 md:translate-x-0 md:relative md:block"
        style={{ 
          backdropFilter: 'blur(12px)',
          WebkitBackdropFilter: 'blur(12px)',
        }}
      >
        <div className="mb-8">
          <div className="flex items-center gap-3 text-white">
            <Droplet size={32} className="fill-white" />
            <span className="text-xl font-bold">BloodBridge</span>
          </div>
        </div>
        <nav className="space-y-2">
          {navItems.map((item) => (
            <motion.button
              key={item.label}
              whileHover={{ x: 4 }}
              onClick={() => {
                onNavigate(item.page);
                setSidebarOpen(false);
              }}
              className="w-full flex items-center gap-3 text-white/90 hover:text-white hover:bg-white/10 p-3 rounded-xl transition-all"
            >
              <item.icon size={20} />
              <span>{item.label}</span>
            </motion.button>
          ))}
        </nav>
      </motion.aside>

      {/* Main Content */}
      <div className="md:ml-64 p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-8">Welcome Back, Donor!</h1>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {statsData.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <GlassmorphicCard>
                  <div className="flex items-center gap-4">
                    <div className={`${stat.color} p-3 rounded-xl`}>
                      <stat.icon size={24} className="text-white" />
                    </div>
                    <div>
                      <p className="text-gray-600 text-sm">{stat.label}</p>
                      <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                    </div>
                  </div>
                </GlassmorphicCard>
              </motion.div>
            ))}
          </div>

          {/* Interactive Map Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="mb-8"
          >
            <GlassmorphicCard className="h-96">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Donor Map - Chennai</h2>
              <div className="bg-gradient-to-br from-red-100 to-red-50 rounded-xl h-80 relative overflow-hidden">
                {/* Mock Map with Pins */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="relative w-full h-full">
                    {[...Array(15)].map((_, i) => (
                      <motion.div
                        key={i}
                        className="absolute"
                        style={{
                          left: `${20 + Math.random() * 60}%`,
                          top: `${20 + Math.random() * 60}%`,
                        }}
                        animate={{
                          y: [0, -10, 0],
                        }}
                        transition={{
                          duration: 2 + Math.random(),
                          repeat: Infinity,
                          delay: Math.random() * 2,
                        }}
                      >
                        <MapPin size={24} className="text-red-600 fill-red-600" />
                      </motion.div>
                    ))}
                  </div>
                </div>
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2">
                  <Button
                    onClick={() => onNavigate('map')}
                    className="bg-red-600 hover:bg-red-700 text-white"
                  >
                    Open Full Map
                  </Button>
                </div>
              </div>
            </GlassmorphicCard>
          </motion.div>

          {/* Quick Actions Grid */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
          >
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Quick Actions</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {quickActions.map((action, index) => (
                <motion.div
                  key={action.label}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: 0.6 + index * 0.1 }}
                >
                  <GlassmorphicCard
                    className="cursor-pointer text-center h-32 flex flex-col items-center justify-center"
                    onClick={() => onNavigate(action.page)}
                  >
                    <div className={`${action.color} p-4 rounded-xl mb-2`}>
                      <action.icon size={24} className="text-white" />
                    </div>
                    <p className="text-gray-900 font-semibold">{action.label}</p>
                  </GlassmorphicCard>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}

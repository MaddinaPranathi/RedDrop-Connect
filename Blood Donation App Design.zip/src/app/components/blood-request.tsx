import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Heart, MapPin, Clock, Share2, Copy, Check } from 'lucide-react';
import { GlassmorphicCard } from './glassmorphic-card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';

interface BloodRequestProps {
  onNavigate: (page: string) => void;
}

export function BloodRequest({ onNavigate }: BloodRequestProps) {
  const [formData, setFormData] = useState({
    patientName: '',
    bloodType: '',
    urgency: '',
    unitsNeeded: '',
    hospital: '',
    location: '',
    contactNumber: '',
    additionalInfo: '',
  });

  const [showPreview, setShowPreview] = useState(false);
  const [copied, setCopied] = useState(false);
  const shareableLink = 'https://bloodbridge.app/request/abc123';

  const handleSubmit = () => {
    setShowPreview(true);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareableLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-red-50 py-12 px-6">
      <div className="max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Request Blood</h1>
          <p className="text-gray-600">Help is on the way - fill out the details below</p>
        </motion.div>

        {!showPreview ? (
          <GlassmorphicCard hover={false}>
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="patientName">Patient Name (Optional)</Label>
                  <Input
                    id="patientName"
                    value={formData.patientName}
                    onChange={(e) => setFormData({ ...formData, patientName: e.target.value })}
                    placeholder="Can remain anonymous"
                    className="bg-white/50"
                  />
                </div>
                <div>
                  <Label htmlFor="bloodType">Blood Type Required *</Label>
                  <Select
                    value={formData.bloodType}
                    onValueChange={(value) => setFormData({ ...formData, bloodType: value })}
                  >
                    <SelectTrigger className="bg-white/50">
                      <SelectValue placeholder="Select blood type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="A+">A+</SelectItem>
                      <SelectItem value="A-">A-</SelectItem>
                      <SelectItem value="B+">B+</SelectItem>
                      <SelectItem value="B-">B-</SelectItem>
                      <SelectItem value="O+">O+</SelectItem>
                      <SelectItem value="O-">O-</SelectItem>
                      <SelectItem value="AB+">AB+</SelectItem>
                      <SelectItem value="AB-">AB-</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="urgency">Urgency Level *</Label>
                  <Select
                    value={formData.urgency}
                    onValueChange={(value) => setFormData({ ...formData, urgency: value })}
                  >
                    <SelectTrigger className="bg-white/50">
                      <SelectValue placeholder="Select urgency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="critical">Critical (Within 6 hours)</SelectItem>
                      <SelectItem value="urgent">Urgent (Within 24 hours)</SelectItem>
                      <SelectItem value="needed">Needed (Within 3 days)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="unitsNeeded">Units Needed *</Label>
                  <Input
                    id="unitsNeeded"
                    type="number"
                    value={formData.unitsNeeded}
                    onChange={(e) => setFormData({ ...formData, unitsNeeded: e.target.value })}
                    placeholder="Number of units"
                    className="bg-white/50"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="hospital">Hospital Name *</Label>
                <Input
                  id="hospital"
                  value={formData.hospital}
                  onChange={(e) => setFormData({ ...formData, hospital: e.target.value })}
                  placeholder="e.g., Apollo Hospital"
                  className="bg-white/50"
                />
              </div>

              <div>
                <Label htmlFor="location">Location *</Label>
                <Select
                  value={formData.location}
                  onValueChange={(value) => setFormData({ ...formData, location: value })}
                >
                  <SelectTrigger className="bg-white/50">
                    <SelectValue placeholder="Select area" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="anna-nagar">Anna Nagar</SelectItem>
                    <SelectItem value="t-nagar">T. Nagar</SelectItem>
                    <SelectItem value="adyar">Adyar</SelectItem>
                    <SelectItem value="velachery">Velachery</SelectItem>
                    <SelectItem value="tambaram">Tambaram</SelectItem>
                    <SelectItem value="chromepet">Chromepet</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="contactNumber">Contact Number *</Label>
                <Input
                  id="contactNumber"
                  type="tel"
                  value={formData.contactNumber}
                  onChange={(e) => setFormData({ ...formData, contactNumber: e.target.value })}
                  placeholder="+91 XXXXX XXXXX"
                  className="bg-white/50"
                />
              </div>

              <div>
                <Label htmlFor="additionalInfo">Additional Information</Label>
                <Textarea
                  id="additionalInfo"
                  value={formData.additionalInfo}
                  onChange={(e) => setFormData({ ...formData, additionalInfo: e.target.value })}
                  placeholder="Any additional details about the case..."
                  className="bg-white/50 h-24"
                />
              </div>

              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
                <p className="text-sm text-yellow-900">
                  <strong>Privacy Note:</strong> Your request will be anonymized if you choose not to provide a patient name. Only verified donors will have access to contact information.
                </p>
              </div>

              <Button
                onClick={handleSubmit}
                className="w-full bg-red-600 hover:bg-red-700 text-white py-6 text-lg"
              >
                <Heart className="mr-2" size={20} />
                Submit Request
              </Button>
            </div>
          </GlassmorphicCard>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
          >
            <GlassmorphicCard hover={false}>
              <div className="text-center mb-6">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', stiffness: 200, damping: 15 }}
                  className="inline-flex items-center justify-center w-16 h-16 bg-green-500 rounded-full mb-4"
                >
                  <Check className="text-white" size={32} />
                </motion.div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Request Submitted!</h2>
                <p className="text-gray-600">Your request has been sent to nearby donors</p>
              </div>

              <div className="bg-white/50 rounded-xl p-6 mb-6">
                <h3 className="font-bold text-gray-900 mb-4">Request Preview</h3>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Heart className="text-red-600" size={20} />
                    <div>
                      <p className="text-sm text-gray-600">Blood Type</p>
                      <p className="font-semibold text-gray-900">{formData.bloodType}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Clock className="text-orange-600" size={20} />
                    <div>
                      <p className="text-sm text-gray-600">Urgency</p>
                      <p className="font-semibold text-gray-900 capitalize">{formData.urgency}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <MapPin className="text-blue-600" size={20} />
                    <div>
                      <p className="text-sm text-gray-600">Location</p>
                      <p className="font-semibold text-gray-900">{formData.hospital}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-red-50 to-pink-50 rounded-xl p-6 mb-6">
                <h3 className="font-bold text-gray-900 mb-3">Share This Request</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Spread the word to find donors faster
                </p>
                <div className="flex gap-2">
                  <Input
                    value={shareableLink}
                    readOnly
                    className="bg-white/50"
                  />
                  <Button
                    onClick={handleCopyLink}
                    className={`${
                      copied ? 'bg-green-600' : 'bg-red-600'
                    } hover:bg-red-700 text-white`}
                  >
                    {copied ? <Check size={18} /> : <Copy size={18} />}
                  </Button>
                </div>
                <div className="flex gap-2 mt-4">
                  <Button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white">
                    <Share2 className="mr-2" size={18} />
                    Share on WhatsApp
                  </Button>
                  <Button className="flex-1 bg-purple-600 hover:bg-purple-700 text-white">
                    <Share2 className="mr-2" size={18} />
                    Share on Social
                  </Button>
                </div>
              </div>

              <div className="flex gap-4">
                <Button
                  onClick={() => onNavigate('dashboard')}
                  variant="outline"
                  className="flex-1"
                >
                  Go to Dashboard
                </Button>
                <Button
                  onClick={() => onNavigate('alerts')}
                  className="flex-1 bg-red-600 hover:bg-red-700 text-white"
                >
                  Track Responses
                </Button>
              </div>
            </GlassmorphicCard>
          </motion.div>
        )}
      </div>
    </div>
  );
}

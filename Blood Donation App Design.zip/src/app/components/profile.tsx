import React, { useState } from 'react';
import { motion } from 'motion/react';
import { User, Edit2, Droplet, Award, Calendar, MapPin, Phone, Mail } from 'lucide-react';
import { GlassmorphicCard } from './glassmorphic-card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';

interface ProfileProps {
  onNavigate: (page: string) => void;
}

const donationHistory = [
  { id: 1, date: '2026-01-15', location: 'Apollo Hospital', units: 1, status: 'Completed' },
  { id: 2, date: '2025-10-20', location: 'Fortis Malar', units: 1, status: 'Completed' },
  { id: 3, date: '2025-07-08', location: 'MIOT Hospital', units: 2, status: 'Completed' },
  { id: 4, date: '2025-04-12', location: 'Chennai Blood Bank', units: 1, status: 'Completed' },
];

const badges = [
  { id: 1, name: 'Life Saver', description: '5+ donations', icon: '🏆', earned: true },
  { id: 2, name: 'Hero', description: '10+ donations', icon: '⭐', earned: false },
  { id: 3, name: 'Regular Donor', description: 'Donated 3 times this year', icon: '🎖️', earned: true },
  { id: 4, name: 'Champion', description: '20+ donations', icon: '👑', earned: false },
];

export function Profile({ onNavigate }: ProfileProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [profileData, setProfileData] = useState({
    name: 'Rajesh Kumar',
    bloodType: 'O+',
    phone: '+91 98765 43210',
    email: 'rajesh.kumar@email.com',
    location: 'Anna Nagar, Chennai',
    lastDonation: '2026-01-15',
    totalDonations: 8,
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-red-50 py-12 px-6">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-2">My Profile</h1>
          <p className="text-gray-600">Manage your donor information</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Donor Card */}
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              <GlassmorphicCard hover={false}>
                <div className="text-center">
                  <div className="relative inline-block mb-4">
                    <div className="w-24 h-24 bg-gradient-to-br from-red-500 to-red-700 rounded-full flex items-center justify-center">
                      <User size={48} className="text-white" />
                    </div>
                    <div className="absolute -bottom-2 -right-2 bg-white rounded-full p-2 shadow-lg">
                      <Droplet size={20} className="text-red-600 fill-red-600" />
                    </div>
                  </div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-1">{profileData.name}</h2>
                  <div className="inline-block bg-red-600 text-white px-4 py-1 rounded-full font-bold text-lg mb-4">
                    {profileData.bloodType}
                  </div>
                  <div className="space-y-2 text-sm text-gray-700">
                    <div className="flex items-center justify-center gap-2">
                      <MapPin size={16} />
                      <span>{profileData.location}</span>
                    </div>
                    <div className="flex items-center justify-center gap-2">
                      <Phone size={16} />
                      <span>{profileData.phone}</span>
                    </div>
                    <div className="flex items-center justify-center gap-2">
                      <Mail size={16} />
                      <span>{profileData.email}</span>
                    </div>
                  </div>
                  <Button
                    onClick={() => setIsEditing(!isEditing)}
                    className="w-full mt-6 bg-red-600 hover:bg-red-700 text-white"
                  >
                    <Edit2 className="mr-2" size={16} />
                    {isEditing ? 'Cancel' : 'Edit Profile'}
                  </Button>
                </div>
              </GlassmorphicCard>

              {/* Stats */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
                className="mt-6"
              >
                <GlassmorphicCard>
                  <h3 className="font-bold text-gray-900 mb-4">Quick Stats</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-700">Total Donations</span>
                      <span className="font-bold text-red-600 text-xl">{profileData.totalDonations}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-700">Lives Saved</span>
                      <span className="font-bold text-green-600 text-xl">{profileData.totalDonations * 3}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-700">Last Donation</span>
                      <span className="font-semibold text-gray-900">Jan 15, 2026</span>
                    </div>
                  </div>
                </GlassmorphicCard>
              </motion.div>
            </motion.div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Edit Form or Badges */}
            {isEditing ? (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <GlassmorphicCard hover={false}>
                  <h3 className="text-2xl font-bold text-gray-900 mb-6">Edit Profile</h3>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        value={profileData.name}
                        onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                        className="bg-white/50"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="phone">Phone</Label>
                        <Input
                          id="phone"
                          value={profileData.phone}
                          onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                          className="bg-white/50"
                        />
                      </div>
                      <div>
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          value={profileData.email}
                          onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                          className="bg-white/50"
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="location">Location</Label>
                      <Input
                        id="location"
                        value={profileData.location}
                        onChange={(e) => setProfileData({ ...profileData, location: e.target.value })}
                        className="bg-white/50"
                      />
                    </div>
                    <Button
                      onClick={() => setIsEditing(false)}
                      className="w-full bg-red-600 hover:bg-red-700 text-white"
                    >
                      Save Changes
                    </Button>
                  </div>
                </GlassmorphicCard>
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <GlassmorphicCard hover={false}>
                  <div className="flex items-center gap-3 mb-6">
                    <Award className="text-red-600" size={28} />
                    <h3 className="text-2xl font-bold text-gray-900">Badges & Achievements</h3>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {badges.map((badge, index) => (
                      <motion.div
                        key={badge.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.1 + index * 0.1 }}
                        className={`p-4 rounded-xl border-2 text-center ${
                          badge.earned
                            ? 'bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-400'
                            : 'bg-gray-50 border-gray-200 opacity-50'
                        }`}
                      >
                        <div className="text-4xl mb-2">{badge.icon}</div>
                        <h4 className="font-bold text-gray-900 mb-1">{badge.name}</h4>
                        <p className="text-xs text-gray-600">{badge.description}</p>
                        {badge.earned && (
                          <div className="mt-2 text-xs font-semibold text-green-600">Earned!</div>
                        )}
                      </motion.div>
                    ))}
                  </div>
                </GlassmorphicCard>
              </motion.div>
            )}

            {/* Donation History Timeline */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <GlassmorphicCard hover={false}>
                <div className="flex items-center gap-3 mb-6">
                  <Calendar className="text-red-600" size={28} />
                  <h3 className="text-2xl font-bold text-gray-900">Donation History</h3>
                </div>
                <div className="space-y-4">
                  {donationHistory.map((donation, index) => (
                    <motion.div
                      key={donation.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.2 + index * 0.1 }}
                      className="relative pl-8 pb-4 border-l-2 border-red-300 last:border-l-0 last:pb-0"
                    >
                      <div className="absolute left-0 top-0 -translate-x-1/2 w-4 h-4 bg-red-600 rounded-full" />
                      <div className="bg-white/50 p-4 rounded-xl">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h4 className="font-bold text-gray-900">{donation.location}</h4>
                            <p className="text-sm text-gray-600">
                              {new Date(donation.date).toLocaleDateString('en-US', {
                                month: 'long',
                                day: 'numeric',
                                year: 'numeric',
                              })}
                            </p>
                          </div>
                          <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-semibold">
                            {donation.status}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-700">
                          <Droplet size={16} className="text-red-600" />
                          <span>{donation.units} {donation.units === 1 ? 'unit' : 'units'} donated</span>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </GlassmorphicCard>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}

import React from 'react';
import { motion } from 'motion/react';

interface GlassmorphicCardProps {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
}

export function GlassmorphicCard({ children, className = '', hover = true }: GlassmorphicCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      whileHover={hover ? { y: -4, boxShadow: '0 8px 30px rgba(220, 38, 38, 0.15)' } : {}}
      className={`backdrop-blur-md bg-white/20 rounded-2xl p-6 shadow-[0_4px_20px_rgba(220,38,38,0.1)] ${className}`}
      style={{
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
      }}
    >
      {children}
    </motion.div>
  );
}
